from flask import Flask, render_template,redirect, request, g
import mysql.connector

app = Flask(__name__)
DB_CONFIG = {
	'host': 'localhost',
	'user':'root',
	'password':'riviera404',
	'database':'database_small'
} 

@app.route("/")
def ghome():
	headers=[]
	headers_t=[]
	headers_c=[]
	try:
		conn=mysql.connector.connect(**DB_CONFIG)
		c=conn.cursor()
		print("Connected!")
		rows=c.execute('SELECT player_name, birthday, height, weight, Player_rating FROM player_simple_rating_small')
		players=c.fetchall()
		for val in c.description:
			headers.append(val[0])
		rows_t=c.execute('SELECT Team_name,`player-1`,`player-2`,`player-3`,`player-4`,`player-5`,`player-6`,`player-7`,`player-8`,`player-9`,`player-10`,`player-11`,Team_rating,Team_shooting,Team_passing,Team_defence FROM teamsfinal_small')
		teams = c.fetchall()
		for val in c.description:
                	headers_t.append(val[0])
	
		rows_c=c.execute('SELECT * FROM Country')
		countries = c.fetchall()
		for val in c.description:
			headers_c.append(val[0])

		c.close()
		return render_template('index.html', countries=countries, teams=teams, players=players, headers_c=headers_c, headers_t = headers_t, headers=headers)
	except mysql.connector.Error as err:
		print("Error connecting to database: {err}")
		return None

		

#@app.route('/', methods=['GET', 'POST'])

def get_db():
	db = getattr(g, '_database', None)  # All spaces
	if db is None:
		db = g._database = mysql.connector.connect(**DB_CONFIG)
		cur=db.cursor(dictionary=True)
	return db


def get_headers(query):
	headers=[]
	conn=mysql.connector.connect(**DB_CONFIG)
	c=conn.cursor(dictionary=True)
	c.execute(query)
	for val in c.description:
		headers.append(val[0])
	conn.close()
	return headers

def query_db(query, args=(), one=False):
	#cur = get_db().execute(query, args)
	db=get_db()
	cur=db.cursor()
	cur.execute(query,args)
	rv = cur.fetchall()
	cur.close()
	return (rv[0] if rv else None) if one else rv


@app.route('/searchplayer', methods=['GET','POST'])
def searchplayer():
	print ("In search!!")
	if request.method == "POST":
		search_value1 = request.form.get('search_player1')
		search_value2 = request.form.get('search_player2')
		print(search_value1)
		print(search_value2)

		##############################
		#collect player1 data # 
		##############################
		selected_player1_all = query_db("SELECT player_api_id, player_name FROM Player_small WHERE player_name LIKE %s OR player_name LIKE %s",('%' + search_value1 + '%', '%' + search_value1 + '%'))
		if(selected_player1_all):
			player1_name=selected_player1_all[0][1]
			player1_api_id=selected_player1_all[0][0]
			print ("Querying player_api_id:", player1_api_id)
			print("Querying player name:", player1_name)
			selected_player1_team = query_db('SELECT Team_name FROM teamsfinal_small WHERE `player-1` LIKE %s OR `player-2` LIKE %s OR `player-3` LIKE %s OR `player-4` LIKE %s OR `player-5` LIKE %s OR `player-6` LIKE %s OR `player-7` LIKE %s OR `player-8` LIKE %s OR `player-9` LIKE %s OR `player-10` LIKE %s or `player-11` LIKE %s', ('%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%'))[0][0] 
			player1_column_query = """
			SELECT
			   CASE 
			     WHEN `player-1` LIKE %s THEN 'player-1'
			     WHEN `player-2` LIKE %s THEN 'player-2'  
			     WHEN `player-3` LIKE %s THEN 'player-3'
			     WHEN `player-4` LIKE %s THEN 'player-4'
                             WHEN `player-5` LIKE %s THEN 'player-5'
                             WHEN `player-6` LIKE %s THEN 'player-6'
			     WHEN `player-7` LIKE %s THEN 'player-7'
                             WHEN `player-8` LIKE %s THEN 'player-8'
                             WHEN `player-9` LIKE %s THEN 'player-9'
                             WHEN `player-10` LIKE %s THEN 'player-10'
                             WHEN `player-11` LIKE %s THEN 'player-11'
                           END AS player1_matching_column
			FROM 
			  teamsfinal_small
			WHERE 	
			  Team_name LIKE %s      	
			"""
			player1_column_data = query_db(player1_column_query, ('%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + player1_name + '%', '%' + selected_player1_team + '%'))
			selected_player1_simple = query_db("SELECT * FROM player_simple_rating_small WHERE player_name LIKE %s OR player_name LIKE %s",('%' + search_value1 + '%', '%' + search_value1 + '%'))
			print(player1_name, " : ", selected_player1_team, " : ", player1_column_data[0][0])
			selected_player1_attribs = query_db("SELECT overall_rating, preferred_foot, crossing, finishing, heading_accuracy, dribbling, ball_control, sprint_speed, shot_power from player_attributes_simple WHERE player_api_id LIKE %s", (player1_api_id,))
			selected_player1_rating = selected_player1_attribs[0][0]
			selected_player1_column = player1_column_data[0][0]
			print(player1_name, " : ", selected_player1_team, " : ", selected_player1_column, " : ", selected_player1_rating)
		else:
			print("Player1 not found in database!")
		##################################
		# collect player2 data #
		##################################	
		selected_player2_all = query_db("SELECT player_api_id, player_name FROM Player_small WHERE player_name LIKE %s OR player_name LIKE %s",('%' + search_value2 + '%', '%' + search_value2 + '%'))
		if(selected_player2_all):
			player2_name=selected_player2_all[0][1]
			player2_api_id=selected_player2_all[0][0]
			print ("Querying player_api_id:", player2_api_id)
			print("Querying player name:", player2_name)
			selected_player2_team = query_db('SELECT Team_name FROM teamsfinal_small WHERE `player-1` LIKE %s OR `player-2` LIKE %s OR `player-3` LIKE %s OR `player-4` LIKE %s OR `player-5` LIKE %s OR `player-6` LIKE %s OR `player-7` LIKE %s OR `player-8` LIKE %s OR `player-9` LIKE %s OR `player-10` LIKE %s or `player-11` LIKE %s', ('%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%'))[0][0]
			player2_column_query = """
                        SELECT
                           CASE 
                             WHEN `player-1` LIKE %s THEN 'player-1'
                             WHEN `player-2` LIKE %s THEN 'player-2'
                             WHEN `player-3` LIKE %s THEN 'player-3'
                             WHEN `player-4` LIKE %s THEN 'player-4'
                             WHEN `player-5` LIKE %s THEN 'player-5'
                             WHEN `player-6` LIKE %s THEN 'player-6'
                             WHEN `player-7` LIKE %s THEN 'player-7'
                             WHEN `player-8` LIKE %s THEN 'player-8'
                             WHEN `player-9` LIKE %s THEN 'player-9'
                             WHEN `player-10` LIKE %s THEN 'player-10'
                             WHEN `player-11` LIKE %s THEN 'player-11'
                           END AS player2_matching_column
                        FROM 
                          teamsfinal_small
                        WHERE   
                          Team_name LIKE %s                                                                                                                                                               
			"""
			player2_column_data = query_db(player2_column_query, ('%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + player2_name + '%', '%' + selected_player2_team + '%'))
			selected_player2_simple = query_db("SELECT * FROM player_simple_rating_small WHERE player_name LIKE %s OR player_name LIKE %s",('%' + search_value2 + '%', '%' + search_value2 + '%'))
			selected_player2_attribs = query_db("SELECT overall_rating, preferred_foot, crossing, finishing, heading_accuracy, dribbling, ball_control, sprint_speed, shot_power from player_attributes_simple WHERE player_api_id LIKE %s", (player2_api_id,))
			selected_player2_rating = selected_player2_attribs[0][0]
			selected_player2_column = player2_column_data[0][0]
			print(player2_name, " : ", selected_player2_team, " : ", selected_player2_column, " : ", selected_player2_rating)
		else:
			print("Player2 not found in database!")
		################################
		# Process form buttons #
		################################
		if ((request.form.get('action')=='compare')and(selected_player1_all)and(selected_player2_all)) :
			headers=get_headers("SELECT overall_rating, preferred_foot, crossing, finishing, heading_accuracy, dribbling, ball_control, sprint_speed, shot_power from player_attributes_simple")
			return render_template('searchplayer.html', headers=headers, playername1=player1_name, searchplayers1=selected_player1_attribs, playername2=player2_name, searchplayers2=selected_player2_attribs)
			
		if ((request.form.get('action')=='exchange')and(selected_player1_all)and(selected_player2_all)):
			# swap names in teamsfinal_small and teams_names_clean_small and recompute rating #
			print("Swapping at column : ", selected_player1_column, "by adding in", player2_name, "in team", selected_player1_team)
			print("Swapping at column : ", selected_player2_column, "by adding in", player1_name, "in team", selected_player2_team)
			swap_query1_1 = f'UPDATE teamsfinal_small SET `{selected_player1_column}` = %s WHERE Team_name = %s'
			swap_data1_1 = (player2_name, selected_player1_team)
			swap_result1_1 = query_db(swap_query1_1, swap_data1_1)
			swap_query1_2 = f'UPDATE teams_names_clean_small SET `{selected_player1_column}` = %s WHERE Team_name = %s'
			swap_data1_2 = (player2_name, selected_player1_team)
			swap_result1_2 = query_db(swap_query1_2, swap_data1_2)
			swap_query2_1 = f'UPDATE teamsfinal_small SET `{selected_player2_column}` = %s WHERE Team_name = %s'
			swap_data2_1 = (player1_name, selected_player2_team)
			swap_result2_1 = query_db(swap_query2_1, swap_data2_1)
			swap_query2_2 = f'UPDATE teams_names_clean_small SET `{selected_player2_column}` = %s WHERE Team_name = %s'
			swap_data2_2 = (player1_name, selected_player2_team)
			swap_result2_2 = query_db(swap_query2_2, swap_data2_2)
			get_db().commit() 
			headers=get_headers("SELECT overall_rating, preferred_foot, crossing, finishing, heading_accuracy, dribbling, ball_control, sprint_speed, shot_power from player_attributes_simple")
			return render_template('searchplayer.html', headers=headers, playername1=player1_name, searchplayers1=selected_player1_attribs, playername2=player2_name, searchplayers2=selected_player2_attribs)
		
		
			
		if(request.form.get('action')=='addplayer'):
			return render_template('addplayer.html')				
	
		if(request.form.get('action')=='remplayer'):
			return render_template('remplayer.html')				
			
		else:
			return ghome()			
	else:
		print ("Returning to main!!")
		return ghome()


@app.route('/remplayer',methods=['GET', 'POST'])
def remplayer():
	print("Removing player from DB")
	if request.method=='POST':
		player_data=request.form.to_dict()
		print("Player to be removed: ", player_data['name'])
		update_query1='DELETE FROM player_small WHERE player_name = %s'
		q1=query_db(update_query1, (player_data['name'],))	
		update_query2='DELETE FROM player_simple_rating_small WHERE player_name = %s'
		q2=query_db(update_query2, (player_data['name'],))
		get_db().commit()
	return render_template('remplayer.html')


@app.route('/addplayer', methods=['GET','POST'])
def addplayer():
	print("Adding player to DB")
	if request.method=='POST':
		player_data=request.form.to_dict()
		print(player_data)
		# Update player tables
		player_count=query_db('SELECT COUNT(*) FROM player_attributes_simple')[0][0]
		print('Player count:', player_count)
		id = player_count+1
		player_api_id = 800000+id
		fifa_api_id = player_api_id
		index1 = id
		level_0 = id
		update_query1='INSERT INTO player_small (index1, id, player_api_id, player_name, player_fifa_api_id, birthday, weight, height) VALUES (%s, %s, %s, %s,%s, %s, %s, %s)'
		q1=query_db(update_query1, (index1, id, player_api_id, player_data['name'], fifa_api_id, player_data['dob'], player_data['height'], player_data['weight']))
		update_query2='INSERT INTO player_simple_rating_small (level_0, player_name, birthday, height, weight, Player_rating) VALUES (%s, %s, %s, %s, %s, %s)'
		q2=query_db(update_query2, (level_0, player_data['name'], player_data['dob'], player_data['height'], player_data['weight'], player_data['overall_rating'])) 
		get_db().commit()
	return render_template('addplayer.html')

@app.route('/searchteams', methods=['GET','POST'])
def searchteams():
	print ("In search!!")
	if request.method == "POST":
		search_value1 = request.form.get('search_team1')
		search_value2 = request.form.get('search_team2')
		print(search_value1)
		print(search_value2)
                #team1
		selected_team1_all = query_db('SELECT Team_name,`player-1`,`player-2`,`player-3`,`player-4`,`player-5`,`player-6`,`player-7`,`player-8`,`player-9`,`player-10`,`player-11`,Team_rating FROM teams_names_clean_small  WHERE team_name LIKE %s OR team_name LIKE %s',('%' + search_value1 + '%', '%' + search_value1 + '%'))
		if(selected_team1_all):
			team1_name=selected_team1_all[0][1]
			print ("Querying team:", team1_name)
                #team2
		selected_team2_all = query_db('SELECT Team_name,`player-1`,`player-2`,`player-3`,`player-4`,`player-5`,`player-6`,`player-7`,`player-8`,`player-9`,`player-10`,`player-11`,Team_rating FROM teams_names_clean_small WHERE team_name LIKE %s OR team_name LIKE %s',('%' + search_value2 + '%', '%' + search_value2 + '%'))
		if(selected_team2_all):
			team2_name=selected_team2_all[0][1]
			print("Querying team name:", team2_name)
		#print(selected_team2_all)
		if((selected_team2_all)and(selected_team1_all)): 
			headers=get_headers('SELECT Team_name,`player-1`,`player-2`,`player-3`,`player-4`,`player-5`,`player-6`,`player-7`,`player-8`,`player-9`,`player-10`,`player-11`,Team_rating from teams_names_clean_small')
			return render_template('searchteams.html', headers=headers, searchteams1=selected_team1_all, searchteams2=selected_team2_all)
		else:
			return ghome()	
		
	else:
		print ("Returning to main!!")
		return render_template('index.html')


if __name__ == "__main__":
	app.run(debug=True)
